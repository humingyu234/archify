# Code Analysis Quick Start

An explicitly requested GitHub PR uses the same workbench:

```sh
node bin/archify.mjs code-analysis prepare /path/to/repo --pr https://github.com/OWNER/REPO/pull/42 --out out/pr-42 --locale zh-CN
node bin/archify.mjs start /path/to/repo --pr 42 --repository OWNER/REPO --out out/pr-42
```

`--scope` selects a repository-relative directory (default: the supplied local subdirectory). PR mode captures the merge-base and head as immutable Git blobs and runs the existing analyzer on both with one captured configuration and language adapter. `--language` and `--locale` retain their normal meanings. The local checkout and index are not changed; repository code, hooks and package scripts are not executed.

The native workbench shows head findings, source evidence, review decisions and AI tasks. Its comparison stays against the PR merge-base; refreshing recaptures the requested PR. Failed runs preserve the last successful result. Atlas keeps before/after counts and the complexity distribution visible. Green `+` and amber `◇` mark added and changed captured objects; red dashed curves mark removed dependencies whose endpoints remain in head. Removed objects stay in the change list and open base source through the shared source pane. Source-side buttons switch between captured base and head text. Ambiguous function names are not paired. Source changes do not establish changed runtime behavior or a confirmed defect; an existing head finding is not automatically introduced by the PR. External reports retain the original binding, coverage and comparison limits; this workflow does not run an AI reviewer.

Capture snapshots remain under the chosen output directory so live tasks and review decisions can verify the pinned head even if the local checkout changes. Review acceptance uses the configured baseline and existing service authorization. Offline tasks stay labeled as captured evidence; verify the intended checkout and source revision before editing.

In a PR report, Atlas **Files** opens the captured changed-file list. Select
**All captured files** to browse the repository listing. Search matches both
paths of a rename. Select a changed file to open its merge-base or PR-head
source at the exact saved commit. A source control is disabled when its side
was absent or its contents were outside capture. **Download .md** records the
repository, both commits and the selected file's repository-relative paths
and availability, without source text.

PR priorities use a bounded impact layer over the saved facts and graph, not the whole head's existing hotspots. It compares changed dependency edges and module fan-in/out, reads exact definition fingerprints only in changed source files, and reuses the existing incoming-reference reader to locate direct callers/importers, including unchanged source files. A same-metric body change remains a reading signal; position-only movement does not become an impact. Existing constraints appear only as context attached to a changed dependency or coupling witness. Rule-report evidence updates alone are not promoted to increased risk.

This layer performs no new extraction or repository traversal. Reading is bounded to 32 changed files, 4 MiB of paired source, 80 changed definitions and 160 result records; each reference preview is bounded. Unsupported models, parse errors, excluded roles and exhausted budgets remain explicit unknowns. This is direct static orientation, not runtime tracing, behavior equivalence or complete transitive impact. Full head findings remain separately available as background. The PR brief copies change evidence and its coverage rather than unrelated whole-head recommendations.

In PR mode, short file/function addition and removal counts follow the original module labels, with detailed counts available on hover. Change badges (+/−/◇) open the captured source; grey dashed spikes show merge-base complexity alongside the current spikes. Removed functions can be marked against a surviving file; deleted files/modules remain in the change list. These annotations do not appear in ordinary repository analysis. A same-metric source edit can have a change badge without implying increased complexity or changed behavior.

## Offline review of two local commits

Use exact Git commit IDs to generate a self-contained review without contacting GitHub:

```sh
node bin/archify.mjs code-analysis prepare /path/to/repo \
  --base <40-character-base> --head <40-character-head> --language ts \
  --out out/pinned-review
```

Provision the Code Analysis dependencies and language tools beforehand. Git objects
needed by the selected scope must be available locally. Missing commit or tree
objects produce a diagnostic, and a failed run keeps the last good report.
The reader compares the selected base directly with head. To match GitHub's PR
comparison, resolve and pass its merge-base yourself. A dirty checkout, Git
branch moves and untracked files do not change the selected commits or evidence.
For a large repository, use `--scope <repo-directory>` to select a subtree.
Git uses 50% similarity to detect renames; moves across the scope boundary
appear as additions or removals, and Git may skip expensive similarity searches
when more than 1000 unmatched paths remain.

Open `out/pinned-review/analysis/repo.analysis.html` directly in a browser.
**Review commits** shows the full Git identities. **Files** in Atlas lists
changed files, and a rename links both saved paths. Source buttons are available
for captured text. Changed files outside the analysis selection may still have
a preview if they are regular UTF-8 files (up to 128 KiB per file and 4 MiB
per side for supplemental previews). These previews do not expand analysis coverage. **Architecture assessment**
links observed dependency changes to source. For JS/TS, add an existing
`--ir architecture.json` and optional `--map overlay-map.json` to compare
authored component relations using the same static analysis as `drift`.
Select a relation to highlight its components or open its import evidence.
Uncertain ownership, resolution and parsing remain visible in the relation.

**Download review .md** exports both commits, changed paths, recorded
dependency changes, source coordinates and coverage. The export omits source
text. The HTML includes captured source excerpts and tasks. Share it with
people who may read that source. You can also use the same pinned options with
`archify start` or `code-analysis serve`.

From the `archify/` package directory inside the Archify repository:

```sh
npm start -- "/path/to/project" --locale zh-CN
```

Open the printed URL. Without `--ir`, analysis starts on page load: the left workbench presents priorities and task-copy controls, alongside the interactive whole-repository Atlas. Select a finding to highlight its Atlas evidence; **Open source evidence** returns from Atlas to the left reader. Narrow screens stack the workbench above Atlas.

To align an existing authored architecture diagram, add `--ir architecture.json`. That mode still delivers the original diagram first and analyzes only after **Code Analysis** is clicked. Use **Atlas** / **Classic view** to switch views; source mapping and IR validation are preserved. `--map` requires `--ir`.

In either mode choose a priority or browse all findings, copy an AI task, and inspect captured source excerpts. **Show full file** expands a snippet. The task labels its evidence status; verify source before editing. `--locale en|zh-CN` overrides the diagram locale; without an override the IR locale is used, then English. Unrecognized IR locales fall back to English.

Keep the terminal running. After changing source code or the `--config` file, click **Re-analyze** on the overview: the repository and the config are read again without restarting, the page reloads with the new result, and the overview shows what changed since the previous analysis (new, no longer detected, and findings whose code changed). A finding that is no longer detected is not necessarily fixed: if the config, the rules that ran, or the files that parsed changed between the two runs, the comparison is marked as not directly comparable and says why (see [Comparing runs](#comparing-runs)). If a re-analysis fails, the last good result stays in place and the reason is shown next to the button. Only a changed architecture JSON needs a restart.

Analysis reads the working tree, including uncommitted and untracked source files. Results are labeled **Working tree**; any base commit is context only. Source panels use the text captured during extraction, and working-tree results do not provide commit-based source links. The raw facts retain that source text and a snapshot digest so findings, graphs, and source panels refer to the same extraction. Non-Git directories are supported.

The source panel marks captured changes against the base commit: green gutters for added lines, amber for modified lines, and red deletion markers between lines. This includes staged and unstaged changes; files absent from the base are labeled **New file**. Markers stay tied to the captured source, so re-analyze to see later edits. Without a readable Git base, the panel reports that markers are unavailable rather than treating every line as new.

If the architecture JSON changes or becomes unavailable after startup, the analysis request is rejected and the page asks you to regenerate the diagram. Restart with the updated JSON and open the new URL. The server never rewrites your input JSON or silently combines a new architecture with the previous diagram.

JavaScript, TypeScript, Python, Java, Go, Rust, C and C++ are selectable. Select one
with `--language ts|py|java|go|rust|c|cpp`; `ts` covers both JavaScript and TypeScript.
Each run uses one adapter; the [language reference](LANGUAGE-REFERENCE.md) has example commands and limits. A JS/TS or Python tree that also holds `.java` files
keeps its language unless its root has a Maven/Gradle build file (see the
[upgrade note](JAVA.md)). Choose explicitly for a mixed-language root. Add
`--map overlay-map.json` when you need an explicit mapping between diagram
components and code modules.

Language extraction has its own prerequisites:

| Adapter | Required tools and source scope |
| --- | --- |
| `ts` | Node.js; the module's bundled TypeScript parser. |
| `py` | Node only; transplanted Pyright parser, Python 3.14 syntax by default. Set `python.targetVersion` to 3.8–3.14. |
| `java` | Node.js; the module's bundled `java-parser` dependency; no JDK or project build. |
| `go` | Go 1.18+ and a root `go.mod`; see [Go scope and tooling](GO.md). |
| `rust` | Cargo/rustc 1.71+, a root `Cargo.toml` and the locked helper dependencies; see [Rust scope and tooling](RUST.md). |
| `c`, `cpp` | An existing `compile_commands.json`, Python clang bindings and libclang; see [C/C++ scope and tooling](C_CPP.md). |

The Go and Rust adapters compile Archify's source helper, not the target
project. Rust's first use may fetch the helper's locked dependencies; cached
dependencies are required for `rust.offline`. These tools remain necessary
when optional duplicate detection is enabled.

For a Java analysis without a diagram, run `node bin/archify.mjs code-analysis check /path/to/java-repo --language java --out out/java`. No JDK or project build is required. See [Java support and limitations](JAVA.md) for conservative dependency resolution, complexity measurements and syntax coverage.

Output defaults to a system temporary directory. Add `--out out/my-project` to choose a persistent output directory. Use the printed URL: double-clicking a static HTML file cannot start local code analysis.

You can also run `node bin/archify.mjs start "/path/to/project" [--ir architecture.json] [--locale zh-CN]` directly. The legacy `code-analysis serve` command remains supported.

## Agent entry and investigation

Code Analysis is independent of native diagrams, explainers and stories. Ordinary diagram requests use `finalize` and deliver the diagram alone. For architecture health, coupling, cycles, configured layers, large files, complexity or refactoring orientation, prepare the standalone investigation directly:

```sh
node bin/archify.mjs code-analysis prepare /path/to/repo --out out/project-analysis --language ts --locale zh-CN
```

Use `--ir architecture.json` only for an existing relevant diagram or an explicit request to align authored architecture boundaries. Do not author JSON merely to unlock analysis. Each run handles one adapter and discloses other languages; select the adapter from source counts. Tool prerequisites and first-run installs affect preparation time, so report measured latency rather than a fixed speed promise.

`prepare` shares extraction, rules, tasks and result publication with `serve`, then exits. The JSON receipt gives scoped counts, coverage, priority leads and `html` (`out/project-analysis/analysis/repo.analysis.html`); `diagram` is null without IR, otherwise names the untouched delivered diagram. Open the HTML directly: the workbench and Atlas are ready offline, with captured tasks, source excerpts, an architecture brief and manual-copy fallbacks.

Report publication and workbench review saves share an output-directory lock. A retry clears a stopped writer's staging before publication when it can verify the writer is gone. Linux retries check the system boot and process namespace before interpreting a PID. They also check the process start time when the same PID is still visible and its identity can be compared.

If the lock owner is active or cannot be verified, `analysis/output-busy` leaves the lock in place. Use a separate `--out` for independently retried containers or machines, including when a retained lock predates this owner check. After `analysis/output-recovery-required`, keep the output, move plan, and backups together for recovery.

Under **Recheck after edits**, copy the saved start command and run it on the generating machine. It preserves language, locale, config, baseline and optional IR/map. Without IR, opening the printed URL starts analysis and compares with the captured result; with IR, click Code Analysis. Later edits use **Re-analyze**. The report never runs a command automatically. Tasks remain captured snapshots until current source is verified.

Deliver the analysis HTML with one or two scoped conclusions; tasks may be given to a coding AI or investigated in the current conversation. Users need not learn command flags or supply a maintenance objective. Preserve a separately delivered diagram if analysis fails, and disclose the coverage/tool gap.

The reader follows explicit `--locale`, then `meta.locale`: `zh-CN` uses Chinese, `en` and unrecognized locales use English. Source text, symbol names, rule identifiers, imported diagnostics and exported task evidence retain their original language. The first screen summarizes error-level diagnostics, file cycles, module dependency loops and configured layer rules. A zero is scoped to checks that ran; a rule that did not run is labelled as unchecked. Information-level signals remain available through finding filters. Select a priority card title to see its measurements and source location directly in the finding. The copy icon on the card copies the AI task without opening the finding; a check mark confirms success briefly without adding a status message. The **Copy architecture brief** icon shares the bounded hotspot and structural orientation with the headless receipt; its order is not inferred business importance.

Atlas shows the relationship map and the four labelled repository totals in the right sidebar. **Map** and **Files** are short tabs. Map stays selected by default. Files replaces the map with a searchable captured-file list; it does not add a third column or a lower scrolling region. Hover a tab for its explanation, or use Left/Right and Home/End while a tab is focused. Choosing a file replaces the current finding and highlights its owner module when you return to Map; choosing a module/finding or clearing the selection replaces the file. The right panel previews and downloads its path, module and captured function names/lines as Markdown. This is navigation context from the saved analysis, without source content or complete diagnostic/task evidence; use a finding's source evidence and task actions for those. No fresh source or external-tool verification is implied. The complexity distribution, the scrollable module list, the dependency records and the legend are visible without expanding anything. Selecting a module smoothly expands its outer arc and dims unrelated modules; inspecting a function retains the selected module. When you leave a finding in the standalone report, Atlas restores the previous selection, zoom, tab and search. Use **Hide analysis** to free space for the star map and the left-edge grip to bring the reader back.

After edits, the prominent comparison reports **no longer detected**, **new** and changed evidence. Missing findings do not prove fixes. Configuration, grouping, model or coverage changes make results non-comparable and show the reason. Verify source changes and project tests before claiming an improvement.

## Verify a previous task after edits

1. Open a finding's **Task preview and download**, then click **Download task JSON** before editing. Use the Markdown or copy action to hand the task to a developer or coding agent.
2. Make the change, run the project's checks separately, and **Re-analyze** in the live workbench, or run `prepare` again with the same output directory. Keep the immediately previous capture; running analysis again rotates the pair.
3. Under **Verify a previous task**, select the task JSON and preview the analysis observations. To record your project checks, download the checks template, enter short check names and their statuses (`passed`, `failed`, `skipped`, or `not-run`), then load it and preview again. **Download verification JSON** exports the combined receipt. The prepared HTML works offline; these files are read in the browser and never sent to the local service.

The receipt distinguishes observed finding changes from checks reported by the user. It does not run tests, verify their execution, or prove a fix. New findings are counted for the captured scope, not attributed to the task. Limited comparisons, missing evidence and unchanged imported reports are marked inconclusive where applicable. Refresh external reports with their original tools and settings before re-analysis; different bytes alone still do not prove the tool ran against the captured source. Do not put commands, logs or secrets into check names.

For the same flow headlessly, point `verify-change` at the `analysis/` directory from `prepare` or `serve`. It reads the adjacent `analysis.previous/` capture. Example from the package directory:

```sh
node bin/archify.mjs code-analysis verify-change out/project-analysis/analysis --task task.json --checks-template > checks.json
# Edit checks.json to record the checks and results you actually ran.
node bin/archify.mjs code-analysis verify-change out/project-analysis/analysis --task task.json --checks checks.json > verification.json
```

Omit `--checks` to record only analysis observations. Use the original task JSON: its ID must match the selected findings. Exit 0 means the receipt was produced (even if project checks failed or the comparison was inconclusive); exit 2 returns a JSON error on stdout with `status: "error"` and `diagnostics` instead of a receipt. `task --verify` remains a separate current-source evidence check.


## Review architecture drift between two commits

Use `drift` when a code change may invalidate an existing Architecture diagram.
It compares observed directed component pairs under the **same** authored IR
and component mapping. Unlike `check --ir`, it says which relationship was
already observed and which is newly observed in the selected head.

```sh
node bin/archify.mjs code-analysis drift /path/to/local/repo \
  --base BASE_FULL_SHA --head HEAD_FULL_SHA --ir architecture.json \
  --map overlay-map.json --out /path/to/new-review-directory --json
```

Use two full local Git commit SHAs and a fresh output directory outside the
source repository (with an existing parent). `--map` is optional and uses the
same component-to-module mapping as `check --ir`. `--config` supplies one
Code Analysis configuration for both pins. Use `--locale en` or
`--locale zh-CN` to choose the review language. An authored IR with repository
evidence must pin either compared commit and pass the ordinary Architecture
delivery checks.

Open `architecture-drift.html` offline and choose **Architecture drift**.
Select a relationship to see its direction on the diagram and its evidence in
the side panel. Source buttons open the captured import line and identify the
exact commit; the panel never reads the current working tree. **Download .md**
saves the selected relationship, both pins, source paths and line numbers, and
coverage limits, without copying the source text. `architecture-drift.json`
contains the same comparison used by the page. `--json` also prints it to
stdout. Exit 0 means the comparison was produced, even when it reports an
undeclared relationship or inconclusive evidence. Errors exit 2 with
structured diagnostics. Existing `check` gates and ordinary render output
are unchanged.

For a newly observed undeclared relationship, download its Markdown and
**Download verification task .json**. Keep the original report JSON alongside
the task. After the prospective change is committed, run `drift` again using
the first report's head as the new base and the same IR, mapping and config.
Pass `--from-report original/architecture-drift.json` to check the starting
commit, IR, mapping and configuration against that report. This also lets
you reuse an IR that pins the original base revision.

```sh
node bin/archify.mjs code-analysis verify-drift original/architecture-drift.json \
  --task DRIFT-<id>.json --after follow-up/architecture-drift.json
```

The verification receipt reports `not-observed-at-head`, `still-observed`, or
`inconclusive` for that pair. If the starting observation cannot be reproduced
or the relevant source does not parse, the outcome is inconclusive. The task
is tied to the original report bytes. Save those bytes without reformatting.
The verifier accepts saved drift reports up to 32 MiB each.
Add `--checks-template` to generate a template, and then pass the completed
template with `--checks <checks.json>` to record project checks. The command
records these results as reported, without running or verifying the checks.

The first version covers resolved module-scope static JS/TS imports, exports
and requires, excluding type-only, conditional and deferred references. It
uses committed files only. It does not check out refs, run project scripts,
load local dependency configuration outside the capture, or fetch missing
objects. Symlinks and submodules are omitted and disclosed. A link change,
conflicting ownership, missing component coverage, affected parse errors, or a
change in resolution inputs can make a relationship inconclusive. A new
import site on an existing pair is still an existing relationship. Unmapped
and unresolved source is outside the report; even a report with no added
relationship does not establish full-coverage alignment or runtime behavior.

## First look at an unfamiliar repository

Run `check` without a diagram (or pass `--ir architecture.json [--map overlay-map.json]` to verify diagram-to-code component mapping and undeclared component-level imports alongside the headless check) and write the artifacts to a directory:

```sh
node bin/archify.mjs code-analysis check /path/to/repo --language ts --out out/first-look --json
```

Archify selects an adapter automatically when it is the only eligible choice. In a mixed tree, the leading adapter must account for at least 90% of files matched by eligible adapters. Go or Rust also needs a regular `go.mod` or `Cargo.toml`, respectively, at the analysis root. A C or C++ lead still requires a choice because source counts cannot tell which files have unique compilation commands. The [Java detection rules](JAVA.md) still apply, and the C++ adapter also covers C when both match.

When Archify needs a choice, `extract/adapter-ambiguous` reports the source counts and corresponding `--language` flags. An explicit `--language` takes precedence. Each run reports the other languages and their file counts in `coverage.otherLanguages`.

Start from the JSON receipt, not the full finding list:

- `investigation.leads` repeats the three ranked `priorities` with `message`, `where` (`path:line`), `symbol`, `impact`, and a runnable `task` command. The text output prints the same list under **Start here**.
- `investigation.architecture` provides deterministic module-graph orientation (`modules`, `edges`, `hotspots`, `strongestEdges`) plus up to five open `structuralSignals` (`coupling/*` and `architecture/*`) that sit outside `leads`, each with its own runnable `task` command so function-complexity warnings never hide architectural signals. Connected hotspots sort by `loc * (1 + log2(1 + fanIn))`, then fan-in, fan-out and ID. Each includes `readingWeight`, and `hotspotRanking` states the rule. This balances size with incoming dependencies; it is a reading order, not inferred business importance or a reason to refactor.
- `investigation.shell` identifies the command syntax: `cmd.exe` on Windows and `POSIX sh` elsewhere. Copy the command into that shell. Spaces and apostrophes are preserved; Windows paths with `%` or `!` use a Node argv launcher to avoid environment-variable expansion. The `drillDown` template quotes `<id>`; replace it with a finding ID.
- `diagram` (when `--ir` is supplied) reports `mappedComponents`, `emptyComponents`, `unmappedModules`, `ambiguousModules`, `offDiagramFindings`, and `undeclaredEdges` (uniquely attributed cross-component code imports absent from `ir.connections`). Directory `sources` use captured file ownership, including Go package paths, Rust crates and configured groups; `.` selects the analyzed root. More specific directories take precedence for their files. A file anchor or explicit `--map` associates the whole folded module with a component. If several components claim the same module, their import attribution remains unresolved and `ambiguousModules` names them. Those imports retain their module-level evidence and are omitted from `undeclaredEdges`. Inspect both unmapped and ambiguous modules before judging alignment. Without `--ir`, `counts.offDiagram` is `null`.

`components[].sources` is an array of one to three objects, such as
`[{"path":"src/cli"}]`; a string array is a schema error with a repair diagnostic.
`check --ir` validates this shared shape while accepting an otherwise partial
architecture IR. Full `start`/`deliver` additionally require a renderable IR and,
when sources are present, pinned `meta.repository` and its matching Git checkout.
A directory reference verifies that tree at the pinned revision and links to the
directory; it has no `line`/`end_line` and does not prove its descendants were
inspected. A leading `./` and one trailing `/` are normalized; `.` denotes the
repository root for pinned evidence. Mapping uses paths relative to the analysis
root (or repository-relative paths with that root prefix); a pinned source always
names a path relative to the Git top level. Use a concrete file with line numbers
when the claim needs source-level evidence.
- `ruleCounts` shows how findings divide by rule, so a dominant rule is visible before reading every finding.
- `coverage` lists parse failures and languages left out. When there are parse failures or role exclusions, `analyzedFiles` counts successfully parsed files in the graph and rule scope. The top-level `files` count can include failed files retained by an extractor for source navigation or partial facts. Role exclusions also report `excludedByRole` and `excludedRoleCounts`. Coverage does not change the finding gate.

For each lead you keep, run its `task` command (or `archify code-analysis task out/first-look --finding <id> --root /path/to/repo --format json`) to get source excerpts, facts, suggestions, acceptance and evidence digests. Then read the cited source before changing code. A finding is static evidence, not a proven defect: a complexity warning says the function is harder to read and test, not that it must be split, and a coupling signal may be an intentional design. If the branching or dependency is inherent, record that and leave the code as it is.

## Architecture boundaries

To check that layers only depend on what they should, pass a config file with `--config analysis.config.json`:

```json
{
  "boundaries": {
    "layers": {
      "domain": ["src/domain/**"],
      "ui": ["src/ui/**", "src/components/**"],
      "shared": ["src/shared/**"]
    },
    "rules": [
      { "from": "domain", "disallow": ["ui"], "reason": "domain logic stays UI-free" },
      { "from": "shared", "allow": [] }
    ]
  }
}
```

Each rule names a `from` layer and either `disallow` (layers it must not import) or `allow` (the only other layers it may import; `[]` means none). A file matching several layers belongs to the first one listed. Imports involving files outside every layer, and test or generated files, are not checked. Every import that breaks a rule is listed as evidence, grouped into one finding per layer pair.

Boundaries come only from this config. The architecture diagram is not used as a rule: a missing arrow on the diagram does not forbid a dependency. Without `boundaries`, the overview lists architecture boundaries as not checked. Coverage shows how many files each layer matched; a layer matching no files usually means a mistyped glob. An invalid `boundaries` block stops analysis with `config/boundaries-invalid`.

## Entry points

`coupling/internal-leak` reports when other modules import a module's internal files instead of going through one entry point. Each such module is one finding listing every import that reaches inside it, the files reached, and the modules that import them.

A module's entry files are, in order:

1. files matching `rules.coupling.internalLeak.entries` in the config, when you declare your convention;
2. otherwise an `index.*` (JS/TS) or `__init__.py` (Python) directly in the module's folder.

```json
{ "rules": { "coupling": { "internalLeak": { "entries": ["src/*/index.ts", "src/*/api.ts"], "minFiles": 3 } } } }
```

Severity follows what is known about your convention:

- **warning**: you declared entry files and imports bypass them;
- **info**: an `index.*` or `__init__.py` exists and imports bypass it, or the module has no entry file and other modules reach `minFiles` (default 3) or more of its files. Deep imports are a common, deliberate style in ES modules and Python packages, so without a declared convention this is a signal, not a defect.

Imports within one module, test and generated files, and modules under a `vendor/` or `third_party/` folder are not checked. Java is not checked: a package's public classes are its interface. If deep imports are your convention, add `"coupling/internal-leak"` to `ignore`. An invalid option stops analysis with `config/internal-leak-invalid`.

In the Atlas, focusing any module marks the files other modules import, whether or not the rule fired; see [Atlas view](#atlas-view).

## Function complexity

Every Python and JS/TS function is measured the same way. **Cyclomatic complexity** is 1 plus one for each decision point:

Java methods and constructors use the same thresholds, with the Java-specific decision points and naming described in [Java complexity](JAVA.md#complexity).

| | Python | JS/TS |
| --- | --- | --- |
| Conditions | `if`/`elif` | `if`/`else if` |
| Loops | `for`/`while` | `for`/`for…in`/`for…of`/`while`/`do` |
| Error handling | `except` | `catch` |
| Conditional expressions | `x if c else y` | `c ? x : y` |
| Cases | non-default `case` | non-default `case` |
| Boolean operators | each extra `and`/`or` operand | each `&&`, `||`, `??` (and `&&=`, `||=`, `??=`) |
| Comprehensions | each `for`/`if` clause | — |

Optional chaining (`?.`) is not counted. **Nesting depth** is the deepest stack of blocks; `elif`/`else if` stays at its `if`'s depth.

Nested named functions are measured on their own:
- in Python: methods and nested `def`s;
- in JS/TS: methods, constructors, accessors, and arrow or function expressions assigned to a name.

Lambdas and anonymous callbacks count toward the function that contains them. A callback at module level has no such function, so it is measured on its own, named after the call it is passed to, and its first literal argument, such as `<callback of server.on("request")>`. Test, generated and vendored files are skipped: `roles.generated` includes `vendor/`, `vendored/`, `third_party/` and `third-party/` by default, because bundles there are not first-party source. Override `roles.generated` in a config to measure those folders and keep them in the module graph.

A function is reported as info from complexity 15 or nesting 5, and as a warning from complexity 25 or nesting 6. Function length is shown as context but never reported on its own. A high count is a maintenance signal, not a defect. The problem page links to the function's first line and its deepest nested block.

To change the thresholds, set any of them in the `--config` file; unset values keep their defaults:

```json
{ "rules": { "complexity": { "function": { "info": { "complexity": 12 }, "warning": { "complexity": 30, "nesting": 7 } } } } }
```


## Severity levels

The colour says what kind of problem a finding is, not which rule reported it.

| Colour | Level | Meaning | What to do |
| --- | --- | --- | --- |
| Red | `error` | A structural problem: a circular dependency. The parts involved cannot be understood, tested or changed on their own, and cycles tend to grow. | Fix it. It can be accepted in the baseline so CI is not blocked, but it stays red on the page. |
| Yellow | `warning` | The code runs, but people will find it hard to maintain: duplicated code (when C6 is enabled), a hub or concentrated module, a very large file, a very complex function, a crossed boundary. | Review it. Fix it, or accept it with a reason. |
| Blue | `info` | A signal to read. | Nothing is required; it does not affect the verdict or CI. |

Red means "structure that should be fixed", not "proven to fail at runtime". An import cycle shows static structure and a possible load-order risk; the messages keep that wording.

How cycles are graded:

| Finding | Level |
| --- | --- |
| `coupling/import-cycle`: files that import each other at module scope | error |
| `coupling/import-cycle`: a cycle that only closes through deferred or conditional imports | warning |
| `coupling/cycle` in Java: packages that depend on each other | error |
| `coupling/import-cycle` in Java: classes that refer to each other | warning: classes load on demand, so there is no load-order risk, and mutual references between classes are common |
| `coupling/cycle`: modules that depend on each other through module-scope imports | error |
| `coupling/cycle`: a component that only closes through deferred, conditional or type-only edges | warning |
| Rust file and module cycles | info: files of one crate compile together, and mutual `use` is ordinary there |

**Upgrading.** Before rule version 2, file cycles were warnings and module and Java cycles were info. `check` fails on warnings by default, so a project whose only cycles were module-level or Java cycles passed and will now fail. When `check` fails without `--baseline`, its receipt includes the exact command for this project (language and config included). To adopt the new levels without blocking CI on existing cycles, record them once and commit the file:

```sh
node bin/archify.mjs code-analysis check "/path/to/project" --baseline analysis-baseline.json --update-baseline --reason "existing cycle, tracked in <issue>"
```

A comparison with a run made before the change is marked not comparable (the rule versions differ), so a changed level is not misread as a new or fixed problem.

In rule version 3 of `coupling/import-cycle`, Java class cycles went from error back to warning. They still fail `check` at the default `--fail-on warning`, but they no longer stay red once accepted, and Java package cycles (`coupling/cycle`) remain errors.

## Concentration

`coupling/concentration` reports where too much of the project sits in, or depends on, one place. It reports numbers, not a verdict that something must be split.

| Reason | Reported when | Default |
| --- | --- | --- |
| reach | a share of the other modules depend on a module, directly or through other modules | `reachShare: 0.5` |
| size | a module holds a share of the analyzed source lines | `sizeShare: 0.4` |
| file | a source file reaches a number of lines | `fileLines: 1500` |

Reach and size compare one module with the rest, so they are only checked when the project has at least `minModules` modules (default 6). Reach counts static dependencies of every kind, including deferred and type-only imports; it is not runtime impact. Test and generated files are not measured.

Findings are warnings, with one exception: high reach alone in a module that depends on no other module is info. That is a shared kernel, which is what the cycle rules recommend moving shared code into. A high-reach module with dependencies of its own passes their changes on to most of the project, so it stays a warning.

```json
{ "rules": { "coupling": { "concentration": { "reachShare": 0.6, "fileLines": 2000 } } } }
```

If the concentration is intended, accept the finding with that reason. An accepted finding is shown again when the module's or file's source changes.

## Duplicate code (C6, optional)

All six source languages can use **jscpd 5.4.3** to report token duplicates as
`redundancy/duplicate-block` warnings. Install the native executable separately
using [jscpd's distribution instructions](https://github.com/kucherenko/jscpd/blob/b82d84186389590fed0813d005391f3b8147dcfa/README.md#quick-start),
then enable it in the existing analysis config:

```json
{
  "duplicates": {
    "enabled": true,
    "executable": "/absolute/path/to/jscpd",
    "minTokens": 50,
    "minLines": 5,
    "identifiers": "exact",
    "timeoutMs": 30000,
    "maxFileBytes": 1000000
  }
}
```

Run from the `archify/` package directory:

```sh
node bin/archify.mjs code-analysis check /path/to/project --language ts --config analysis.config.json --out out/analysis --json
```

Use the same `duplicates` configuration with `--language py`, `java`, `go` or
`rust`. Each invocation checks the selected adapter's captured source scope;
it does not combine all languages in a mixed repository or expand Go/Rust
build/profile coverage.

C6 compares the raw text of those selected files. In Rust, text inside an
inactive `cfg` region or an opaque macro can still match. Duplicate coverage
describes scanned files; it does not establish runtime reachability or coverage
of every build profile.

These are the defaults when `enabled` is true. `executable` defaults to `jscpd`
on PATH; a relative path containing a directory separator is resolved from the
caller's working directory. On Windows select the native `.exe`, not an npm
`.cmd` launcher. No detector is downloaded or installed by an analysis run.
When the block is absent, `enabled` is false, or `ignore` includes
`redundancy/duplicate-block`, the optional executable is not probed or run.
The selected language's extraction prerequisites above still apply. C6 adds
the jscpd executable to that setup; it does not replace the language adapter.

The mode is `weak`: whitespace and comments are ignored, while identifiers and
literals remain significant. Set `identifiers` to `consistent` to also consider
consistent renaming; this is a different matching policy, not a more accurate
default. Python docstrings and TypeScript declarations can still be repeated
tokens. Review their purpose before deciding to change code. These thresholds
have been sampled on real source but are not a universal maintenance threshold.

The detector scans a temporary UTF-8 copy of the already captured source,
following the selected language and module file roles. Test/generated roles
follow `modules.excludeRoles`; conventional `vendor`, `vendored`, `third_party`
and `third-party` directories are omitted. Parse failures, unsupported formats
and files above `maxFileBytes` are also recorded as omissions. The temporary
tree is removed after the invocation; the target project's code is not executed.

`findings.json` records engine/version, effective settings and selected/analyzed/
omitted paths under `analysis.duplicates`; `check --json` includes the same data
under `duplicates`. Native reports also omit files below their token/line limits;
when the report does not state an individual reason, it stays
`not-reported-by-engine`. An incomplete or empty scan is visible even with zero
findings: the CLI summary warns, `overview.json` records `coverage.duplicates`
(analyzed/selected/omitted counts and `complete`), and the page marks Coverage as
incomplete with `Duplicate code: x/y files analyzed · incomplete`. Comparisons involving incomplete coverage, a changed scan scope,
settings or engine are marked not directly comparable. Missing tools, wrong
versions, timeouts and invalid reports fail the analysis with exit 2; they do not
become clean results, even with `--fail-on never`.

Each finding retains one **native pair** and both locations, including duplicates
within one file. It does not infer every pair in a larger group. Coordinates are
converted from jscpd's UTF-8 byte offsets to UTF-16 source offsets and one-based
columns. IDs distinguish content, file, enclosing symbol and repeated occurrence;
leading lines and unrelated findings do not change them, but changing clone
content or the number of identical occurrences can produce new IDs.

The existing `task` command exports both sides and their allowed files. Evidence
hashes cover the complete cited lines, including context beside a partial-line
match. Both sides are checked independently; unique unchanged ranges can move,
while ambiguous moves or a changed number of identical copies invalidate the
old evidence. The original line-level evidence formats remain supported.
In the page, **Duplicate code** shows both file paths and complete short matched
ranges. Theme-coloured highlighting and an underline follow the recorded columns; text
beside a partial-line match stays unmarked. The mark denotes the detector's token
range, whose whitespace or comments may differ under `weak` mode. Long ranges
show bounded beginning/end excerpts with an explicit omission count. Open either
file to inspect its complete source; the exact marks survive full-file expansion
and returning to the finding. Older results without columns show a notice and
leave the source unmarked. The two locations are stacked in the existing reader.

## Accepting known findings (baseline)

Real projects have findings the team knows about and has decided to leave for now. A baseline file records them, so the overview and CI focus on what is new:

```sh
node bin/archify.mjs code-analysis check "/path/to/project" --baseline analysis-baseline.json --update-baseline --reason "existing debt when analysis was adopted"
```

This writes every current finding to `analysis-baseline.json` with that reason. Edit the reasons per entry if you like, and commit the file. Pass it to the page with `--baseline analysis-baseline.json` (`npm start -- … --baseline …`) or to `check`.

- Accepted findings stay listed, marked **accepted** with their reason, but no longer count toward the verdict, the priorities, the diagram colours, or a CI failure.
- An accepted **error** is the exception for colour: it no longer fails CI or counts toward the priorities, but its component stays red and it is marked **accepted · still to fix**. The baseline records a decision to wait, not a repair.
- Each entry remembers a fingerprint of the code it was about. If that code changes, the finding is shown again as **accepted · evidence changed** so someone looks at it once more.
- Entries whose finding no longer occurs are listed as no longer found: the problem was fixed or moved, and the entry can be removed. Running `--update-baseline` again keeps existing reasons, adds new findings, and drops those entries.

## Terminal and CI: `code-analysis check`

`check` runs the same analysis without a diagram and exits with a status a pipeline can use:

```sh
node bin/archify.mjs code-analysis check "/path/to/project" --baseline analysis-baseline.json --fail-on warning --out .analysis
```

| Option | Meaning |
| --- | --- |
| `--fail-on error\|warning\|info\|never` | Fail when an open finding reaches this level (default `warning`). |
| `--baseline file` | Accepted findings do not fail the run unless their code changed. |
| `--out dir` | Publish `raw-facts`, `module-graph`, `findings`, `review` and `overview` JSON together. The last complete run's `findings.json` in that directory is compared with automatically. |
| `--compare findings.json` | Compare with a specific earlier run instead. |
| `--new-only` | Fail only on findings that are new since the comparison, for gating pull requests. Without a previous run to compare with, every open finding counts as new, so a missing comparison artifact cannot pass the gate. |
| `--update-baseline [--reason text]` | Write the baseline instead of checking. |
| `--json` | Print a machine-readable receipt instead of the summary. |

Exit codes: `0` passed, `1` the gate failed, `2` the analysis could not run (the diagnostic says why). A failing run without `--baseline` offers the command that records today's findings in `analysis-baseline.json`, for a first run or after a rule became stricter. If the baseline or drill-down command contains control characters, the summary points to the exact command in the `--json` receipt under `gate.adopt` or `investigation.drillDown`. The printed summary lists failing findings as `path:line` with their ids, the comparison counts, and stale baseline entries.


### Keep the PR comparison fixed across retries

An analysis that exits `1` can still publish its reports. A later run in
the same output directory would use those reports for automatic comparison.
Pass the original comparison file explicitly when retrying a PR gate.

Record the base and head commits from the PR event. Check out their merge base
in `BASE_TREE` and the recorded head in `HEAD_TREE`. Use the same
`ARCHIFY_CLI` (path to `bin/archify.mjs`), `ANALYSIS_LANGUAGE`, and
`ANALYSIS_CONFIG` (path to the shared configuration) for both commands.
Put the output directories outside the checkouts.

Generate the comparison report once for this pair of commits.

```sh
node "$ARCHIFY_CLI" code-analysis check "$BASE_TREE" \
  --language "$ANALYSIS_LANGUAGE" --config "$ANALYSIS_CONFIG" \
  --out "$BASE_OUT" --fail-on never --json
```

After this command exits `0`, save `BASE_OUT/findings.json` with the
comparison's commit IDs and tool configuration. Each attempt restores that
same file and uses a fresh `ATTEMPT_OUT`.

```sh
mkdir -p "$ATTEMPT_OUT" || exit 2
node "$ARCHIFY_CLI" code-analysis check "$HEAD_TREE" \
  --language "$ANALYSIS_LANGUAGE" --config "$ANALYSIS_CONFIG" \
  --compare "$BASE_OUT/findings.json" --new-only --fail-on warning \
  --out "$ATTEMPT_OUT" --json > "$ATTEMPT_OUT/receipt.json"
```

Keep the CLI exit status when the step ends. Save the attempt reports and
receipt for exits `0` and `1`, including when findings block the gate.
On exit `2`, save the error receipt. A missing or invalid file passed to
`--compare` produces exit `2`.

## Config files

`--config file.json` is merged into the defaults (`config/defaults.json`):

- objects merge key by key at every depth, so a file that sets one threshold or one file role keeps every other default;
- arrays replace the default list as a whole — `include`, `exclude`, `ignore` and each role's globs. To add an exclusion, copy the default `exclude` list and append to it;
- other values replace the default.

Use `"ignore": ["rule/code"]` to suppress rules. Optional duplicate detection must
first be enabled through `duplicates.enabled`; absent input or configuration
also leaves rules such as architecture boundaries unchecked. A config that is
not a JSON object stops analysis with `cli/config-invalid`.

## Atlas view

The Classic view reads the result against your architecture diagram and opens source evidence. The Atlas draws the analyzed tree itself, so the shape of the problems is visible at once:

- each **module** is an arc around the circle; a thicker arc is a reported hub;
- each **file** is a tick inside its module's arc;
- each **dependency** between two analyzed files is a curve, coloured by the importing module and bundled through both modules, so heavy coupling shows as a thick strand;
- each measured **function** is a spike outside its file, longer for higher cyclomatic complexity; a reported function carries a dot in its severity colour.

Hover for names and numbers. Click a module arc (or a module in the side panel) to focus it: its own dependencies stay coloured, other modules' dependencies on it are drawn in a neutral colour, and the rest fades. A mark inside the rim shows each of its files that other modules import (longer for more importing modules), and the side panel says how many of its files are imported from outside and by how many modules: the module's public surface as the code actually uses it. Click a dotted spike or a finding in the side panel to draw that finding over everything else: a cycle's path, a module cycle's modules, a boundary's crossing imports, the imports reaching inside a module (its arc thickens and its entry files, if any, are ringed), or a function and its file's dependencies. **Open evidence in Classic view** shows the same finding with its source excerpt and AI task.

Motion is used only to show change: the picture grows out from the centre when the Atlas opens, a new focus or finding cross-fades in, and a light travels around a selected import cycle in the direction of its imports. With your system's reduced-motion setting on, everything is drawn at once and stays still.

The Atlas adds no analysis: it draws the raw facts, module graph and findings of the same run. Dependency records that could not be resolved draw no curve; the side panel states how many there are, so a missing curve is not proof that there is no dependency. Test and generated files are left out, as in the module graph. The Atlas needs the raw facts of the run and is not offered without them.

Selecting a module redistributes angular space within the circle: the selected
sector expands while surrounding sectors shrink and move around it. The radius
stays fixed, and sectors remain separate. The wheel adjusts this distribution.
Click the selected arc again, click blank space, use **Clear selection**,
or press **Esc** to return to the overview. **Disable sector zoom** retains the
current selection and dependency highlighting. Function tips and bodies use the
same transformed positions for clicking, and findings reuse the existing source
selection and Classic evidence view. Cross-module findings return to the overview.

## Comparing runs

Every `findings.json` records what the result depends on besides the code: the analyzer version, the extractor (its parser or runtime version and the revision of its own logic), a digest of the effective config, the rules that ran, the excluded file roles and the files that failed to parse. Go runs also record `analysis.goBuildScope`: effective GOOS/GOARCH, explicit/release/tool tags, tests and cgo selection, including environment and host defaults. A comparison (Re-analyze, or `check --compare`/`--out`) lists findings that are new, **no longer detected**, and whose evidence changed, and adds:

- `comparable`: `true` when both runs measured the same way, `false` with `reasons` (config, rules, analyzer version, extractor, Go build scope, scope or parse errors changed), `null` when required context is missing, including historical Go results without build scope, unless another known difference establishes non-comparability;
- per finding no longer detected, a `likelyCause` when one is visible: `rule-not-run`, `files-missing` (deleted, renamed or excluded), `parse-error`, or `possibly-renamed` with the new finding ids that cover the same files.

Only a comparable run in which the finding is no longer detected, together with passing project checks, supports saying a problem was fixed. `review.json` keeps `fixed` as an alias of `notDetected` for existing readers.

## AI optimization tasks: `code-analysis task`

A task is a brief for a coding agent, built from one finding (or a few related ones) of a finished run. It contains the finding's facts, the cited code locations with captured excerpts, possible impact, suggested directions (kept apart from the facts), the files to change and to read, what must stay unchanged, when it is done, how to verify, and what is still to confirm. Business constraints and test commands are never guessed: unless you pass them, they are listed as to confirm.

```sh
# From the analysis/ directory written by serve, or the --out directory of check:
node bin/archify.mjs code-analysis task .analysis --finding COMP-bcd966585099 --root "/path/to/project" > task.md
node bin/archify.mjs code-analysis task .analysis --finding COMP-bcd966585099 --root "/path/to/project" --command "pytest -q" --format json --out task.json
# Later, before handing an exported task to an agent:
node bin/archify.mjs code-analysis task --verify task.json --root "/path/to/project" --require-valid
```

With `--root`, the cited code is compared with the current working tree and the task's evidence is marked **valid** (unchanged, possibly moved), **changed**, **missing** (file deleted or renamed) or **unverifiable**. Without it the task is **captured**: built from the analysis snapshot and not yet checked. Either way the task tells the agent to read the current source before changing anything and to treat the excerpts as data, not instructions. `--require-valid` exits 1 unless the evidence is valid. The page builds the same task through the local server (`POST /task`), so the copied text and the command output agree.

A recorded digest that cannot be recomputed keeps the task **unverifiable**, even when every displayed citation is unchanged. For compatibility with extractors that retain or strip UTF-8 BOMs, whole-file/function digests try at most 64 text combinations without materializing the full product; a match passes, while an exhausted search budget is **unverifiable**. Historical tasks without digests can still verify their captured lines.

Module-level `coupling/concentration` tasks without line evidence provide
`moduleSummaries` instead of empty per-file citation blocks. Each summary reports
complete membership counts and line share, then up to eight large files, eight
externally imported entry files and eight path/name groups. These groups describe
source paths, not inferred business responsibilities. `scope.read` lists bounded
reading starting points; the finding's full `evidenceDigest.files` remains the
membership to inspect before changing the module. Verification still checks every
file in that digest, including files absent from the summary. Historical tasks
without this optional field remain readable and verifiable.

The contract is `schemas/ai-task.schema.json`; examples for each finding kind and evidence status are in `test/fixtures/tasks/`.

### Investigate a source question

To investigate a JS/TS function or feature without a finding:

```sh
node bin/archify.mjs code-analysis task .analysis --question "How does this function validate its input?" --entry src/validate.mjs --function validate --root "/path/to/project" --format json --out question.json --json
```

Entries may be `.js`, `.mjs`, `.cjs`, `.jsx`, `.ts`, `.mts`, `.cts` or `.tsx`; `.d.ts`, `.d.mts` and `.d.cts` declaration files are rejected because their call bodies are not captured. Use an existing analysis directory when available; omitting it keeps missing facts explicit. `--function` is optional and accepts a captured name or qualified name. The output records entry/source identity, direct import freshness, captured and indexed scope, and up to 40 calls in the selected source range. Inspect `calls.coverage`, `total` and `omitted`: unavailable coverage has a null total; a captured zero only means no collected CallExpressions in that range. The JSON receipt repeats call coverage so it remains visible with `--json`.

Changed or unavailable entry facts and entry parse errors return exit 1. A usable entry returns exit 0 even when call coverage is unavailable; the output remains `orientation-only`. Neither code means the semantic question has been answered. Call targets describe supported lexical bindings, with separate source-freshness checks, not runtime execution or complete impact. The host Agent completes the [function analysis workflow](FUNCTION-ANALYSIS.md), reading current source and verifying consequential claims before delivering an answer. Finding export and verification options remain separate from question mode.

### Investigate a changed source file

Capture two JS/TS roots using the
current extractor and one analysis configuration:

```sh
node bin/archify.mjs code-analysis task --question "Which source paths changed?" --base-root "/path/to/base" --root "/path/to/head" --entry src/validate.mjs --format json --out "/path/to/review/change.json" --json
```

`--entry` is required. The output must be outside both roots. This mode accepts
uncommitted sources; it reads files without executing the target application. It
compares text/function locations, records lexical call references and keeps module
import references separate. It does not use an existing analysis directory or
accept `--function`. Optional `--config` applies one analysis configuration to both
sides; observed compiler/package differences limit binding attribution.

The receipt reports per-side `definitionCoverage` and any incomplete-coverage
reasons. Parse/freshness failures, unsupported declaration entries or different
resolution settings produce partial/exit 1. Lists expose their own omissions;
ready/exit 0 means usable orientation, not complete impact or zero omissions. No
saved raw-facts directory is produced. Follow the [change-question workflow](FUNCTION-ANALYSIS.md#change-questions)
to explain behavior from source and project checks. Automatic entry selection,
JSON inventory and a semantic diff are not provided by this mode.


### From the analysis page

Open a priority finding or a component's finding, read the captured code excerpt, then click **Copy task for AI**. One click prepares the complete brief and copies it, without requiring you to open its preview. Paste it into the coding AI working on this project. **Task preview and download** provides the full preview, **Copy AI task**, **Download .md** and **Check again**. Copy and download refresh the task first when the local service is available. If clipboard access is unavailable, the preview opens and selects the text for manual copying.

Parser and schema packages are bundled in `vendor/`, so `serve`, `check` and `task` install nothing. Running a task does not itself connect to an AI recipient: the current UI reports copying or downloading, not sending or starting a refactor.

An offline report exports the captured snapshot and labels it as not checked against current source. Changed, missing, and unverifiable evidence is called out in both the preview and exported brief; ask your coding AI to read the current files before editing. An expired page or a rejected server request requires retry or re-analysis. Export does not apply a patch or execute project checks.

Relationships and metrics are folded below the code evidence. A source link opens the nine-line context; **Show full file** expands the file while preserving function-range highlighting. **Hide analysis** frees space for the canvas; use the restore control to reopen the reader. Unchecked categories remain visible in the overview; a clean result only covers the rules that ran.

### Go source investigation

Use `--language go` at a root containing `go.mod`. An installed Go 1.18+ compiler is required. Saved and paired questions can follow captured direct function declarations and known callers; build scope, test inclusion, excluded files and incomplete typing remain explicit. See [Go support](GO.md) for commands, toolchain cost and limitations.

### Rust source investigation

Use `--language rust` at a Cargo workspace/package root. Cargo/rustc 1.71+ and
the locked helper dependencies are required. Saved and paired questions retain
the captured source profile, cfg/features, omitted regions and bounded call
model; a source binding does not establish compilation or runtime dispatch.
See [Rust support](RUST.md) for setup, profile settings and limitations.

### C and C++ source investigation

Use `--language c` or `--language cpp` with `config.cpp.compileCommands` set to
an existing compilation database. C++ selection also covers C translation
units. Active includes, source function ranges and conservative same-unit
direct calls carry translation-unit contexts. A saved header question requires
`--context <translation-unit>`; a paired question accepts a translation-unit
source entry. See [C/C++ support](C_CPP.md) for setup and limits.
